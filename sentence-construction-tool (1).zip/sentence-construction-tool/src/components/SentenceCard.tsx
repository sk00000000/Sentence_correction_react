import { useEffect, useState } from 'react';
import { useQuiz } from '../context/QuizContext';

interface Props {
  question: {
    id: number;
    sentence: string;
    options: string[];
    answer: string[];
  };
}

export default function SentenceCard({ question }: Props) {
  const [timer, setTimer] = useState(30);
  const [filled, setFilled] = useState<string[]>([]);
  const { setAnswer, current, next } = useQuiz();

  useEffect(() => {
    setFilled([]);
    setTimer(30);
    const interval = setInterval(() => {
      setTimer((prev) => {
        if (prev === 1) {
          clearInterval(interval);
          next();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [question]);

  const handleSelect = (word: string) => {
    if (filled.includes(word)) return;
    const blanks = question.answer.length;
    if (filled.length < blanks) setFilled([...filled, word]);
  };

  const handleUnselect = (index: number) => {
    const updated = [...filled];
    updated.splice(index, 1);
    setFilled(updated);
  };

  const handleNext = () => {
    setAnswer(current, filled);
    next();
  };

  const parts = question.sentence.split('____');

  return (
    <div className="p-6 max-w-xl mx-auto">
      <div className="text-right text-gray-500 mb-4">⏱ {timer}s</div>

      <div className="text-lg mb-6">
        {parts.map((part, i) => (
          <span key={i}>
            {part}
            {i < question.answer.length && (
              <button
                className="inline-block px-3 py-1 mx-1 bg-blue-100 rounded hover:bg-blue-200"
                onClick={() => handleUnselect(i)}
              >
                {filled[i] || '____'}
              </button>
            )}
          </span>
        ))}
      </div>

      <div className="flex flex-wrap gap-2 mb-6">
        {question.options.map((opt, i) => (
          <button
            key={i}
            onClick={() => handleSelect(opt)}
            disabled={filled.includes(opt)}
            className="px-3 py-1 bg-green-100 rounded hover:bg-green-200 disabled:opacity-50"
          >
            {opt}
          </button>
        ))}
      </div>

      <button
        className="bg-blue-600 text-white px-4 py-2 rounded disabled:opacity-50"
        onClick={handleNext}
        disabled={filled.length !== question.answer.length}
      >
        Next
      </button>
    </div>
  );
}
