import { useEffect } from 'react';
import { useQuiz } from '../context/QuizContext';
import SentenceCard from '../components/SentenceCard';
import { useNavigate } from 'react-router-dom';

export default function Quiz() {
  const { questions, setQuestions, current, next } = useQuiz();
  const navigate = useNavigate();

  useEffect(() => {
    fetch('http://localhost:3001/questions')
      .then((res) => res.json())
      .then(setQuestions);
  }, []);

  useEffect(() => {
    if (current >= 10) navigate('/feedback');
  }, [current, navigate]);

  if (questions.length === 0) return <p className="text-center mt-10">Loading...</p>;

  return <SentenceCard question={questions[current]} />;
}
