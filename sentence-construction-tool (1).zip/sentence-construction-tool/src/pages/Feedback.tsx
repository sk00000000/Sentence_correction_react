import { useQuiz } from '../context/QuizContext';

export default function Feedback() {
  const { questions, answers } = useQuiz();
  let score = 0;

  return (
    <div className="p-6 max-w-2xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Feedback</h1>
      {questions.map((q, i) => {
        const correct = JSON.stringify(q.answer) === JSON.stringify(answers[i]);
        if (correct) score++;
        return (
          <div
            key={i}
            className={`p-4 mb-2 rounded ${correct ? 'bg-green-100' : 'bg-red-100'}`}
          >
            <div className="mb-1 font-semibold">Question {i + 1}:</div>
            <div>Your Answer: {answers[i]?.join(' ') || 'Skipped'}</div>
            {!correct && <div>Correct Answer: {q.answer.join(' ')}</div>}
          </div>
        );
      })}
      <div className="mt-6 text-xl font-bold">Score: {score}/10</div>
    </div>
  );
}
