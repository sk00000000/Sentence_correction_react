import { createContext, useState, useContext, ReactNode } from 'react';

interface Question {
  id: number;
  sentence: string;
  options: string[];
  answer: string[];
}

interface QuizContextType {
  questions: Question[];
  current: number;
  answers: string[][];
  setQuestions: (q: Question[]) => void;
  setAnswer: (index: number, answer: string[]) => void;
  next: () => void;
}

const QuizContext = createContext<QuizContextType | undefined>(undefined);

export const QuizProvider = ({ children }: { children: ReactNode }) => {
  const [questions, setQuestions] = useState<Question[]>([]);
  const [current, setCurrent] = useState(0);
  const [answers, setAnswers] = useState<string[][]>([]);

  const next = () => setCurrent((prev) => prev + 1);
  const setAnswer = (index: number, answer: string[]) => {
    const updated = [...answers];
    updated[index] = answer;
    setAnswers(updated);
  };

  return (
    <QuizContext.Provider
      value={{ questions, current, answers, setQuestions, setAnswer, next }}
    >
      {children}
    </QuizContext.Provider>
  );
};

export const useQuiz = () => {
  const context = useContext(QuizContext);
  if (!context) throw new Error('QuizContext must be used within provider');
  return context;
};
