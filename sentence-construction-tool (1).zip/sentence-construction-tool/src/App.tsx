import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Quiz from './pages/Quiz';
import Feedback from './pages/Feedback';
import { QuizProvider } from './context/QuizContext';

export default function App() {
  return (
    <QuizProvider>
      <Router>
        <Routes>
          <Route path="/" element={<Quiz />} />
          <Route path="/feedback" element={<Feedback />} />
        </Routes>
      </Router>
    </QuizProvider>
  );
}
